//package com.ac.springcloudFunctionexample.model;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonProperty;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;
//
//import java.io.Serializable;
//
//@Entity
//@ToString
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@Table(name = "DOCUMENTDATA")
//public class DocumentData implements Serializable {
//
//	private static final long serialVersionUID = 1234L;
//
//  @Column(name = "docid")
//  @Id
//  private String docId;
//
//  @Column(name = "docname")
//  private String docName;
//
//  @Column(name = "doclocation")
//  private String docLocation;
//
//  public boolean hasId() {
//    return this.docId.isEmpty();
//  }
//}
//
