//package com.ac.springcloudFunctionexample.dao;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.data.domain.Example;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Repository;
//
//import com.ac.springcloudFunctionexample.SpringcloudFunctionExampleApplication;
//import com.ac.springcloudFunctionexample.model.DocumentData;
//
//@Repository
//public interface DocumentDataDAO extends JpaRepository<DocumentData, String>
//{
//
//
//}