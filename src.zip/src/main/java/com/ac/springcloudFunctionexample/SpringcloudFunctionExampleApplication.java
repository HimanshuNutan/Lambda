package com.ac.springcloudFunctionexample;
/*
 * In aws handles info should be :  com.ac.springcloudFunctionexample.HandlerFunction
 */

//import com.ac.springcloudFunctionexample.dao.DocumentDataDAO;
//import com.ac.springcloudFunctionexample.model.DocumentData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;

@SpringBootApplication
@ConfigurationPropertiesScan
public class SpringcloudFunctionExampleApplication {

//  public DocumentDataDAO dao;
  @Autowired
  public KafkaTemplate<String, String> kafkaTemplate;

//  @Autowired
//  public SpringcloudFunctionExampleApplication(DocumentDataDAO dao) {
//    this.dao = dao;
//  }

  private static final Logger logger = LoggerFactory.getLogger(SpringcloudFunctionExampleApplication.class);

  public static void main(String[] args) {
    SpringApplication.run(SpringcloudFunctionExampleApplication.class, args);
  }

  @KafkaListener(topics = "TRSQLDB.dbo.trWOHead", groupId = "cbd3dfe2-dd19-42f9-ac69-2a8161a9f043")
  public void getDocumentInfo(String message) throws JSONException {
    System.out.println("Message received - "+message);
//    DocumentData documentData = new DocumentData();
    JSONObject jsonObject = new JSONObject(message);
    JSONObject jsonPayload = jsonObject.getJSONObject("payload");
    String wostatus = jsonPayload.getString("wouserstatus");
//    documentData.setDocId(jsonPayload.getString("docId"));
//    documentData.setDocName("Aadhar");
//    documentData.setDocLocation(jsonPayload.getString("docLocation"));
    System.out.println("WorkOrderStatus is "+wostatus);
//    if(!dao.findById(jsonPayload.getString("docId")).isEmpty()){
//      if(!wostatus.isEmpty()&&wostatus!=null){
//        dao.save(documentData);
//      }}else{
//      System.out.println("Workorder doesn't exist in DB");
//    }
//  }

}}
