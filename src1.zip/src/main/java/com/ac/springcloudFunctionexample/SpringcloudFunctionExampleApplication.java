package com.ac.springcloudFunctionexample;
import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
/*
 * In aws handler info should be :  com.ac.springcloudFunctionexample.HandlerFuction
 */
import java.util.function.Function;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;

@SpringBootApplication
@ConfigurationPropertiesScan
public class SpringcloudFunctionExampleApplication{

	private static final Logger logger = LoggerFactory.getLogger(SpringcloudFunctionExampleApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SpringcloudFunctionExampleApplication.class, args);
	}

	@Autowired
	public KafkaTemplate<String, String> kafkaTemplate;

	@Bean
	public Function<String, String> getDocumentInfo() {
		logger.info("here printing bhawna in getDocumentInfo ");
		getkafkaInfo();
		return value -> "Return Value";
	}
	/*
	@KafkaListener(topics = "TRSQLDB.dbo.trWOHead", groupId = "cbd3dfe2-dd19-42f9-ac69-2a8161a9f043")
		  void commonListenerForMultipleTopics(String message) {
		logger.info("MultipleTopicListener - {}", message);
		  }
	 */

	//@KafkaListener(topics = "TRSQLDB.dbo.trWOHead",groupId = "cbd3dfe2-dd19-42f9-ac69-2a8161a9f043") 
	public void getkafkaInfo() {
		Properties consumerProps = new Properties();
		consumerProps.put("bootstrap.servers", "b-1.test-pvt-cluster.1pji8f.c2.kafka.us-east-2.amazonaws.com:9092,"
				+ "b-2.test-pvt-cluster.1pji8f.c2.kafka.us-east-2.amazonaws.com:9092");
		consumerProps.put("security.protocol", "PLAINTEXT");
		consumerProps.put("sasl.mechanism", "GSSAPI");
		consumerProps.put("ssl.protocol", "TLSv1.2");
		consumerProps.put("ssl.enabled.protocols", "TLSv1.2");
		consumerProps.put("ssl.endpoint.identification.algorithm", "https");
		consumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		consumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		consumerProps.put("group.id", "cbd3dfe2-dd19-42f9-ac69-2a8161a9f043");
		KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumerProps);
		consumer.subscribe(Arrays.asList("TRSQLDB.dbo.trWOHead"));
		while (true) {
			logger.info("in while loop ");
			ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
			logger.info("records - {}", records);
			for (ConsumerRecord<String, String> record : records) {
				logger.info("in for loop - {}", record);
				System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
			}
		}
	}


}