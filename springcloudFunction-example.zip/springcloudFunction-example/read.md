This is a Spring Cloud Function, running on AWS Lambda and has capabilities to interact with Aurora Mysql database and MSK Cluster Kafka Server.

To run on AWS Lambda, build the module and upload the jar to S3.
Pass the S3 link in the Lambda Code Source.

Edit the Runtime Settings and change the handler to "packageName.HandlerFunction"

Pass the config properties as Environment Variables as below

    KEY                  VALUE

DATASOURCE_SECRET     =    "DB Username"

DATASOURCE_PASSWORD   =    "DB Password"

DATASOURCE_URL      =      "DB URL"

DB_DRIVER_CLASS_NAME   =   "DriverClassName"

KAFKA_BROKERS       =      "MSKKafkaBrokersList"

