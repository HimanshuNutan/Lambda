package com.ac.springcloudFunctionexample.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@Builder
public class WorkOrderResponseLineItem {

	private int id;

	@Builder.Default
	private String itemId = "";

	@Builder.Default
	private String departmentId = "";

	@Builder.Default
	private String itemCode = "";

	@Builder.Default
	private String serviceCodeId = "";

	@Builder.Default
	private String serviceCode = "";

	@Builder.Default
	private String location = "";

	@Builder.Default
	private String status = "";

	@Builder.Default
	private String description = "";

	@Builder.Default
	private String actionCode = "";

	@Builder.Default
	private String errorStatus = "";

	private int lineNum;

	private double quantity;

	private int undoGroup;

	@Builder.Default
	private String newLocation = "";

	@Builder.Default
	private String newParent = "";

	@Builder.Default
	private String requestedFor = "";

	private boolean verified;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date verifiedDate;

	private boolean printed;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date scanDate;

	@Builder.Default
	private String importBatchId = "";

	@Builder.Default
	private String importBatchName = "";

	@Builder.Default
	private String inventoryCategory = "";

	private int available;

	@Builder.Default
	private String createdByName = "";

	@Builder.Default
	private String lastModifiedByName = "";

	@Builder.Default
	private String createdBy = "";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date createdDate;

	@Builder.Default
	private String lastModifiedBy = "";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date lastModifiedDate;
}
