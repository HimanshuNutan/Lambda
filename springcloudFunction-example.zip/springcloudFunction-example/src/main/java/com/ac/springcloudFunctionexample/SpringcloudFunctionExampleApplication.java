package com.ac.springcloudFunctionexample;
/*
 * In aws handles info should be :  com.ac.springcloudFunctionexample.HandlerFunction
 */

import java.util.function.Function;

import com.ac.springcloudFunctionexample.dao.WorkOrderRepository;
import com.ac.springcloudFunctionexample.model.WorkOrderResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Bean;
//import org.springframework.kafka.core.KafkaTemplate;

@SpringBootApplication
@ConfigurationPropertiesScan
public class SpringcloudFunctionExampleApplication {

  public WorkOrderRepository workOrderRepository;
//  @Autowired
//  public KafkaTemplate<String, String> kafkaTemplate;

  @Autowired
  public SpringcloudFunctionExampleApplication(WorkOrderRepository workOrderRepository) {
    this.workOrderRepository = workOrderRepository;
  }

  private static final Logger logger = LoggerFactory.getLogger(SpringcloudFunctionExampleApplication.class);

  public static void main(String[] args) {
    SpringApplication.run(SpringcloudFunctionExampleApplication.class, args);
  }

  @Bean
  public Function<String, String> getDocumentInfo() {

    String kafkaTopic = "TestTopic";
    return value -> {
//      value = dao.findById(value).orElse(null).toString();
//      kafkaTemplate.send(kafkaTopic, value);
      logger.info("Checking DB Connection");
      WorkOrderResponse workOrderResponse = workOrderRepository.getWorkOrderByTrWoId(value);
      logger.info("CustomerId -"+workOrderResponse.getCustomerId());
      logger.info("Status Id - "+workOrderResponse.getWoStatusId());
      return workOrderResponse.getWoStatusId();
    };
  }

}
