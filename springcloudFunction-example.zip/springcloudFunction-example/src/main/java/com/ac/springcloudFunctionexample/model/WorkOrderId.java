package com.ac.springcloudFunctionexample.model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrderId {
  private int extId;
  @Builder.Default
  private String extSystemCode = "";
}
