package com.ac.springcloudFunctionexample;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@EnableMongoRepositories
public class HandlerFunction extends SpringBootRequestHandler<String, String> {

}