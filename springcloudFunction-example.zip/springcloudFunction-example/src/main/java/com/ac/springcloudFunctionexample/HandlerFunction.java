package com.ac.springcloudFunctionexample;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

public class HandlerFunction extends SpringBootRequestHandler<String, String> {

}