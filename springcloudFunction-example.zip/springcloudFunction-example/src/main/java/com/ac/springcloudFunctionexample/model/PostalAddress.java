package com.ac.springcloudFunctionexample.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@Builder
public class PostalAddress {

	@JsonIgnore
	@Builder.Default
	private String description = "";

	@JsonIgnore
	@Builder.Default
	private String poBoxNumber = "";


	@Builder.Default
	private String streetAddress = "";

	@Builder.Default
	private String streetAddress2 = "";

	@Builder.Default
	private String locality = "";

	@Builder.Default
	private String region = "";

	@Builder.Default
	private String postalCode = "";

	@Builder.Default
	private String country = "";

	@Builder.Default
	private String email = "";

	@Builder.Default
	private String phone = "";

	@JsonIgnore
	private String mobile;

	@Builder.Default
	private String fax = "";

	@JsonIgnore
	private String contact;

	@JsonIgnore
	private String createdBy;

	@JsonIgnore
	private Date createdDate;

	@JsonIgnore
	private String lastModifiedBy;

	@JsonIgnore
	private Date lastModifiedDate;
}
