package com.ac.springcloudFunctionexample.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Data
@Document(collection = "WorkOrder")
public class WorkOrderResponse {

	@Id
	private String id;

	@Builder.Default
	private String customerId = "";

	@Builder.Default
	private String code = "";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date dueDate;

	@Builder.Default
	private String departmentId = "";

	@Builder.Default
	private String description = "";

	@Builder.Default
	private String comments = "";

	@Builder.Default
	private String priority = "";

	@Builder.Default
	private String status = "";
	
	private String woStatusId;

	@Builder.Default
	private String requestedBy = "";

	private boolean isPermount;

	@Builder.Default
	private String locationId = "";

	private PostalAddress deliveryAddress;

	private WorkOrderId workOrderId;

	private List<WorkOrderResponseLineItem> lines;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date closeDate;

	@Builder.Default
	private String lastModifiedByName = "";

	private boolean recurring;

	@Builder.Default
	private String signedFor = "";

	@Builder.Default
	private String deliveryBatch = "";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date deliveryDate;

	@Builder.Default
	private String customerRef = "";

	private int sequence;

	@Builder.Default
	private String source = "";

	private PostalAddress address2;

	@Builder.Default
	private String createdBy = "";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date createdDate;

	@Builder.Default
	private String lastModifiedBy = "";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private Date lastModifiedDate;
	
}
