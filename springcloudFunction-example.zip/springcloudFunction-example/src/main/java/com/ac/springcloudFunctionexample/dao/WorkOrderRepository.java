package com.ac.springcloudFunctionexample.dao;

import com.ac.springcloudFunctionexample.model.WorkOrderResponse;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface WorkOrderRepository extends MongoRepository<WorkOrderResponse,String>{

	@Query(value = "{'workOrderId.extId':?0}")
	public WorkOrderResponse getWorkOrderByTrWoId(String trWoId);

}
