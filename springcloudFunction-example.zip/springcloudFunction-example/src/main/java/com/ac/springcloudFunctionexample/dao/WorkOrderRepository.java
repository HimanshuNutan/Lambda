package com.ac.springcloudFunctionexample.dao;

import com.ac.springcloudFunctionexample.model.WorkOrderResponse;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface WorkOrderRepository extends MongoRepository<WorkOrderResponse,String>{

	@Query(value = "{'workOrderId.extId':?0}")
	public List<WorkOrderResponse> getWorkOrderByTrWoId(int trWoId);

}
